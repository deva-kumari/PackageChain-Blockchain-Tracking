import os
from flask import Flask
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from models import db, User


def create_app():
    app = Flask(__name__)

    # Configure the SQLAlchemy part of the app
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Simple configuration for sessions and CSRF
    app.config['SECRET_KEY'] = 'dev-super-secret-key-12345'
    app.config['WTF_CSRF_ENABLED'] = True
    app.config['WTF_CSRF_SECRET_KEY'] = 'csrf-secret-key-67890'

    # Initialize SQLAlchemy
    db.init_app(app)

    # Setup Flask-Login
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'user_login'

    # Setup CSRF protection
    csrf = CSRFProtect()
    csrf.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    with app.app_context():
        db.create_all()

        # Create default admin user if it doesn't exist
        if not User.query.filter_by(username='super_admin').first():
            super_admin = User(
                username='super_admin',
                email='super_admin@example.com',
                role='super_admin',
                hub='all'
            )
            super_admin.set_password('super123')
            db.session.add(super_admin)

            admin = User(
                username='admin',
                email='admin@example.com',
                role='admin',
                hub='all'
            )
            admin.set_password('secure123')
            db.session.add(admin)

            staff = User(
                username='staff1',
                email='staff1@example.com',
                role='staff',
                hub='Mumbai'
            )
            staff.set_password('staff123')
            db.session.add(staff)

            # Example user
            user = User(
                username='john_doe',
                email='john@example.com',
                role='user',
                hub=None
            )
            user.set_password('user123')
            db.session.add(user)

            db.session.commit()

    return app
// Main JavaScript file for PackageChain application

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })

    // Initialize Bootstrap popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    })

    // Add particle background to homepage if element exists
    if (document.querySelector('.home-page')) {
        createParticleBackground();
    }

    // Add typing animation to headings if they exist
    if (document.querySelector('.typing-animation')) {
        addTypingAnimation();
    }
});

function createParticleBackground() {
    // Create a container for the particles
    var particlesContainer = document.createElement('div');
    particlesContainer.id = 'particles-js';
    document.querySelector('.home-page').appendChild(particlesContainer);

    // Define particle settings
    var particleSettings = {
        "particles": {
            "number": {
                "value": 80,
                "density": {
                    "enable": true,
                    "value_area": 800
                }
            },
            "color": {
                "value": "#ffffff"
            },
            "shape": {
                "type": "circle",
                "stroke": {
                    "width": 0,
                    "color": "#000000"
                },
                "polygon": {
                    "nb_sides": 5
                }
            },
            "opacity": {
                "value": 0.5,
                "random": false,
                "anim": {
                    "enable": false,
                    "speed": 1,
                    "opacity_min": 0.1,
                    "sync": false
                }
            },
            "size": {
                "value": 3,
                "random": true,
                "anim": {
                    "enable": false,
                    "speed": 40,
                    "size_min": 0.1,
                    "sync": false
                }
            },
            "line_linked": {
                "enable": true,
                "distance": 150,
                "color": "#ffffff",
                "opacity": 0.4,
                "width": 1
            },
            "move": {
                "enable": true,
                "speed": 6,
                "direction": "none",
                "random": false,
                "straight": false,
                "out_mode": "out",
                "bounce": false,
                "attract": {
                    "enable": false,
                    "rotateX": 600,
                    "rotateY": 1200
                }
            }
        },
        "interactivity": {
            "detect_on": "canvas",
            "events": {
                "onhover": {
                    "enable": true,
                    "mode": "grab"
                },
                "onclick": {
                    "enable": true,
                    "mode": "push"
                },
                "resize": true
            },
            "modes": {
                "grab": {
                    "distance": 140,
                    "line_linked": {
                        "opacity": 1
                    }
                },
                "bubble": {
                    "distance": 400,
                    "size": 40,
                    "duration": 2,
                    "opacity": 8,
                    "speed": 3
                },
                "repulse": {
                    "distance": 200,
                    "duration": 0.4
                },
                "push": {
                    "particles_nb": 4
                },
                "remove": {
                    "particles_nb": 2
                }
            }
        },
        "retina_detect": true
    };

    // Load particles.js library and initialize
    if (typeof particlesJS !== 'undefined') {
        particlesJS('particles-js', particleSettings);
    } else {
        console.log('Particles.js library not loaded');
    }
}

function addTypingAnimation() {
    // Get all elements with the typing-animation class
    var typingElements = document.querySelectorAll('.typing-animation');

    typingElements.forEach(function(element) {
        var text = element.textContent;
        element.textContent = '';

        function typeWriter() {
            var i = 0;
            var speed = 50; // typing speed

            function type() {
                if (i < text.length) {
                    element.textContent += text.charAt(i);
                    i++;
                    setTimeout(type, speed);
                }
            }

            type();
        }

        // Start the animation with a slight delay
        setTimeout(typeWriter, 500);
    });
}

// Function to toggle notification bell animation
function animateBell() {
    var bellIcon = document.querySelector('.notification-bell');
    if (bellIcon) {
        bellIcon.classList.add('bell-animation');
        setTimeout(function() {
            bellIcon.classList.remove('bell-animation');
        }, 1000);
    }
}

// Function to confirm delete actions
function confirmDelete(message) {
    return confirm(message || 'Are you sure you want to delete this item?');
}

// Function to copy tracking ID to clipboard
function copyToClipboard(text) {
    var tempInput = document.createElement('input');
    tempInput.value = text;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);

    // Show a temporary tooltip
    var tooltip = document.createElement('div');
    tooltip.className = 'copied-tooltip';
    tooltip.textContent = 'Copied!';
    document.body.appendChild(tooltip);

    setTimeout(function() {
        tooltip.classList.add('fade-out');
        setTimeout(function() {
            document.body.removeChild(tooltip);
        }, 500);
    }, 1000);
}

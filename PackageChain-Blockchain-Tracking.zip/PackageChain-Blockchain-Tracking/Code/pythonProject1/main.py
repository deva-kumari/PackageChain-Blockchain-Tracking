import os
import json
import logging
from functools import wraps
from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
from forms import EditStatusForm
from digital_signature import verify_signature as verify_user_signature, generate_key_pair_for_user
from blockchain import get_block_by_index

import block_chain
import digital_signature
from app import create_app
from models import db, User, Package, Block
from forms import RegistrationForm, LoginForm, AdminLoginForm, TrackForm, CreateShipmentForm, UpdateStatusForm, \
    AddPackageForm, AddUserForm, DeleteUserForm

# Setup logging
logging.basicConfig(level=logging.DEBUG)

app = create_app()

DATA_FOLDER = 'data'
KEYS_FOLDER = 'keys'
os.makedirs(DATA_FOLDER, exist_ok=True)
os.makedirs(KEYS_FOLDER, exist_ok=True)

PACKAGES_FILE = os.path.join(DATA_FOLDER, 'packages.json')
if not os.path.exists(PACKAGES_FILE):
    with open(PACKAGES_FILE, 'w') as f:
        json.dump({}, f)

def ensure_key_pairs():
    with app.app_context():
        users = User.query.all()
        for user in users:
            private_key_path = os.path.join(KEYS_FOLDER, f"{user.username}_private.pem")
            public_key_path = os.path.join(KEYS_FOLDER, f"{user.username}_public.pem")

            if not os.path.exists(private_key_path) or not os.path.exists(public_key_path):
                generate_key_pair_for_user(user.username)


def role_required(roles):
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            if current_user.role not in roles:
                flash(f'You need to have one of these roles: {", ".join(roles)}', 'danger')
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def hub_access_required(f):
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if current_user.role in ['super_admin', 'admin']:
            return f(*args, **kwargs)
        tracking_id = kwargs.get('tracking_id') or request.form.get('tracking_id')
        if tracking_id:
            with open(PACKAGES_FILE, 'r') as file:
                packages = json.load(file)
            if tracking_id in packages:
                latest_block = packages[tracking_id][-1]
                if latest_block['location'].lower() != current_user.hub.lower():
                    flash(f'You do not have access to packages in {latest_block["location"]} hub', 'danger')
                    return redirect(url_for('admin_dashboard'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = RegistrationForm()
    if form.validate_on_submit():
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('Username already exists. Please choose another one.', 'danger')
            return redirect(url_for('register'))

        user = User(
            username=form.username.data,
            email=form.email.data,
            role='user'
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()

        generate_key_pair_for_user(user.username)

        flash('Your account has been created! You can now log in.', 'success')
        return redirect(url_for('user_login'))

    return render_template('register.html', form=form)



# User Login
@app.route('/login', methods=['GET', 'POST'])
def user_login():
    if current_user.is_authenticated:
        return redirect(url_for('user_dashboard' if current_user.role == 'user' else 'admin_dashboard'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('user_dashboard' if user.role == 'user' else 'admin_dashboard'))
        else:
            flash('Login unsuccessful. Please check username and password.', 'danger')

    return render_template('login.html', form=form)

@app.route('/edit_package/<tracking_id>', methods=['GET', 'POST'])
@login_required
def edit_package(tracking_id):
    with open(PACKAGES_FILE, 'r') as file:
        packages = json.load(file)

    if tracking_id not in packages:
        flash('Package not found!', 'danger')
        return redirect(url_for('admin_dashboard'))

    form = EditStatusForm()
    current_status = packages[tracking_id][-1]['status']

    if form.validate_on_submit():
        new_status = form.status.data
        packages[tracking_id][-1]['status'] = new_status

        with open(PACKAGES_FILE, 'w') as file:
            json.dump(packages, file, indent=4)

        flash('Status updated successfully!', 'success')
        return redirect(url_for('admin_dashboard'))

    form.status.data = current_status  # Set current value
    return render_template('edit_package.html', tracking_id=tracking_id, form=form, package=packages[tracking_id][-1])

# Admin Login
@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if current_user.is_authenticated and current_user.is_admin():
        return redirect(url_for('admin_dashboard'))

    form = AdminLoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data) and user.is_admin():
            # TODO: Add 2FA check here if implemented
            login_user(user)
            flash('Admin login successful!', 'success')
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Login unsuccessful. Please check credentials or permissions.', 'danger')

    return render_template('admin_login.html', form=form)


# Logout
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'success')
    return redirect(url_for('index'))


# User Dashboard
@app.route('/user_dashboard')
@login_required
def user_dashboard():
    if current_user.role != 'user':
        return redirect(url_for('admin_dashboard'))

    # Get the user's packages
    user_packages = Package.query.filter_by(user_id=current_user.id).all()

    # You can add notifications logic here
    notifications = []  # This would come from a database table in a real app

    return render_template('user_dashboard.html', user_packages=user_packages, notifications=notifications)


# Create new shipment (for regular users)
@app.route('/create_shipment', methods=['GET', 'POST'])
@login_required
def create_shipment():
    if current_user.role != 'user':
        flash('This feature is only available for regular users.', 'danger')
        return redirect(url_for('index'))

    form = CreateShipmentForm()

    if form.validate_on_submit():
        tracking_id = block_chain.generate_tracking_id()
        sender_name = form.sender_name.data
        receiver_name = form.receiver_name.data
        origin = form.origin.data
        destination = form.destination.data

        # Create package in database
        package = Package(
            tracking_id=tracking_id,
            sender_name=sender_name,
            receiver_name=receiver_name,
            origin=origin,
            destination=destination,
            user_id=current_user.id
        )
        db.session.add(package)
        db.session.commit()

        # Create genesis block for the blockchain
        genesis_block = block_chain.create_genesis_block(
            sender_name, receiver_name, origin, destination, current_user.username
        )

        # Sign the block
        private_key_path = os.path.join(DATA_FOLDER, f"{current_user.username}_private.pem")
        genesis_block['signature'] = digital_signature.sign_data(
            json.dumps(genesis_block, sort_keys=True),
            private_key_path
        )

        # Save to database (this would be part of a proper integration)
        block = Block(
            package_id=package.id,
            index=0,
            location=origin,
            status="Package Registered",
            prev_hash=genesis_block['prev_hash'],
            hash=genesis_block['hash'],
            signature=genesis_block['signature'],
            updated_by=current_user.username
        )
        db.session.add(block)
        db.session.commit()

        # Save to JSON file (temporary until full migration)
        with open(PACKAGES_FILE, 'r') as file:
            packages = json.load(file)

        packages[tracking_id] = [genesis_block]
        with open(PACKAGES_FILE, 'w') as file:
            json.dump(packages, file, indent=4)

        flash(f'Package added successfully with Tracking ID: {tracking_id}', 'success')
        return redirect(url_for('user_dashboard'))

    return render_template('create_shipment.html', form=form)


@app.route('/track', methods=['GET', 'POST'])
def track():
    form = TrackForm()
    tracking_id = None
    blocks = None
    is_valid = False

    # Check if tracking_id is passed as query parameter
    if request.method == 'GET' and 'tracking_id' in request.args:
        tracking_id = request.args.get('tracking_id')
    elif form.validate_on_submit():
        tracking_id = form.tracking_id.data

    if tracking_id:
        with open(PACKAGES_FILE, 'r') as file:
            packages = json.load(file)

        if tracking_id in packages:
            blocks = packages[tracking_id]
            is_valid = block_chain.verify_chain(blocks)
        else:
            flash('Package not found!', 'danger')

    return render_template(
        'track.html',
        form=form,
        tracking_id=tracking_id,
        blocks=blocks,
        is_valid=is_valid
    )


@app.route('/dashboard')
@login_required
def admin_dashboard():
    if not current_user.is_admin():
        return redirect(url_for('admin_dashboard'))


    with open(PACKAGES_FILE, 'r') as file:
        packages = json.load(file)

    filtered_packages = {}
    if current_user.role in ['super_admin', 'admin']:
        filtered_packages = packages
    else:
        for tracking_id, blocks in packages.items():
            if blocks[-1]['location'].lower() == current_user.hub.lower():
                filtered_packages[tracking_id] = blocks

    # Build the package summary with sender/receiver
    enriched_packages = {}
    for tracking_id, blocks in filtered_packages.items():
        enriched_packages[tracking_id] = {
            "sender_name": blocks[0].get("sender_name", "Unknown"),
            "receiver_name": blocks[0].get("receiver_name", "Unknown"),
            "status": blocks[-1].get("status", "Unknown"),
            "location": blocks[-1].get("location", "Unknown"),
            "timestamp": blocks[-1].get("timestamp", "Unknown"),
            "blocks": blocks
        }

    stats = {
        'total_packages': len(enriched_packages),
        'delivered': sum(1 for pkg in enriched_packages.values() if pkg["status"] == "Delivered"),
        'in_transit': sum(1 for pkg in enriched_packages.values() if pkg["status"] != "Delivered"),
        'status_counts': {}
    }

    for pkg in enriched_packages.values():
        status = pkg["status"]
        stats["status_counts"][status] = stats["status_counts"].get(status, 0) + 1

    return render_template(
        'admin_dashboard.html',
        username=current_user.username,
        role=current_user.role,
        hub=current_user.hub,
        packages=enriched_packages,
        stats=stats
    )

@app.route('/add_package', methods=['GET', 'POST'])
@login_required
@role_required(['super_admin', 'admin'])
def add_package():
    form = AddPackageForm()

    if form.validate_on_submit():
        tracking_id = form.tracking_id.data or block_chain.generate_tracking_id()
        sender_name = form.sender_name.data
        receiver_name = form.receiver_name.data
        origin = form.origin.data
        destination = form.destination.data

        # Load package data
        with open(PACKAGES_FILE, 'r') as file:
            packages = json.load(file)

        if tracking_id in packages:
            flash('Tracking ID already exists!', 'danger')
            return redirect(url_for('add_package'))

        # Create the genesis block
        genesis_block = block_chain.create_genesis_block(
            sender_name, receiver_name, origin, destination, current_user.username
        )

        # Sign the block
        private_key_path = os.path.join(DATA_FOLDER, f"{current_user.username}_private.pem")
        genesis_block['signature'] = digital_signature.sign_data(
            json.dumps(genesis_block, sort_keys=True),
            private_key_path
        )

        # Save the package
        packages[tracking_id] = [genesis_block]
        with open(PACKAGES_FILE, 'w') as file:
            json.dump(packages, file, indent=4)

        flash(f'Package added successfully with Tracking ID: {tracking_id}', 'success')
        return redirect(url_for('admin_dashboard'))

    return render_template('add_package.html', form=form)


@app.route('/update_status/<tracking_id>', methods=['GET', 'POST'])
@login_required
@hub_access_required
def update_status(tracking_id):
    # Load package data
    with open(PACKAGES_FILE, 'r') as file:
        packages = json.load(file)

    if tracking_id not in packages:
        flash('Package not found!', 'danger')
        return redirect(url_for('admin_dashboard'))

    form = UpdateStatusForm()

    if form.validate_on_submit():
        location = form.location.data
        status = form.status.data

        # Create a new block
        previous_block = packages[tracking_id][-1]
        new_block = block_chain.create_block(
            previous_block, location, status, current_user.username
        )

        # Sign the block
        private_key_path = os.path.join(DATA_FOLDER, f"{current_user.username}_private.pem")
        new_block['signature'] = digital_signature.sign_data(
            json.dumps(new_block, sort_keys=True),
            private_key_path
        )

        # Add the new block to the chain
        packages[tracking_id].append(new_block)

        # Save the updated package data
        with open(PACKAGES_FILE, 'w') as file:
            json.dump(packages, file, indent=4)

        flash('Package status updated successfully!', 'success')
        return redirect(url_for('admin_dashboard'))

    # Pre-populate the form with the current location
    if not form.location.data:
        form.location.data = packages[tracking_id][-1]['location']

    return render_template('update_status.html', form=form, tracking_id=tracking_id, package=packages[tracking_id])


@app.route('/audit/<tracking_id>')
@login_required
def audit(tracking_id):
    package = Package.query.filter_by(tracking_id=tracking_id).first()
    if not package:
        flash('Package not found.', 'danger')
        return redirect(url_for('admin_dashboard'))
    blocks = Block.query.filter_by(package_id=package.id).order_by(Block.index).all()
    chain_valid = all(block.valid for block in blocks)
    for block in blocks:
        if isinstance(block.timestamp, datetime):
            block.timestamp_str = block.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        else:
            block.timestamp_str = block.timestamp
    return render_template('audit.html', tracking_id=tracking_id, package=package, blocks=blocks, chain_valid=chain_valid)



@app.route('/verify_signature/<tracking_id>/<int:block_index>')
@login_required
def verify_signature(tracking_id, block_index):
    packages_file = PACKAGES_FILE
    if not os.path.exists(packages_file):
        flash("Packages file not found.", "danger")
        return redirect(url_for("track"))
    with open(packages_file, "r") as f:
        all_packages = json.load(f)
    if tracking_id not in all_packages:
        flash("Tracking ID not found.", "danger")
        return redirect(url_for("track"))
    chain_data = all_packages[tracking_id]
    if block_index >= len(chain_data):
        flash("Invalid block index.", "danger")
        return redirect(url_for("track"))
    block = chain_data[block_index]
    data_string = f"{block['index']}-{block['origin']}-{block['destination']}-{block['status']}-{block['location']}-{block['timestamp']}"
    signature = block.get("signature", "")
    signer = block.get("updated_by", "")
    signature_valid = verify_user_signature(signer, data_string, signature)
    return render_template("verify_signature.html", tracking_id=tracking_id, block=block, signature_valid=signature_valid)


@app.route('/manage_users', methods=['GET', 'POST'])
@login_required
@role_required(['super_admin'])
def manage_users():
    users = User.query.all()
    add_form = AddUserForm()
    delete_form = DeleteUserForm()

    # Process the submitted form data
    if request.method == 'POST':
        # Add user form submission
        if 'username' in request.form and add_form.validate_on_submit():
            username = add_form.username.data
            password = add_form.password.data
            role = add_form.role.data
            hub = add_form.hub.data

            if User.query.filter_by(username=username).first():
                flash('Username already exists!', 'danger')
                return redirect(url_for('manage_users'))

            # Create new user
            new_user = User(
                username=username,
                email=f"{username}@example.com",  # Placeholder email
                role=role,
                hub=hub
            )
            new_user.set_password(password)
            db.session.add(new_user)
            db.session.commit()

            # Generate keys for the new user
            private_key_path = os.path.join(DATA_FOLDER, f"{username}_private.pem")
            public_key_path = os.path.join(DATA_FOLDER, f"{username}_public.pem")
            digital_signature.generate_key_pair(private_key_path, public_key_path)

            flash(f"User '{username}' added successfully!", 'success')
            return redirect(url_for('manage_users'))

        # Delete user form submission
        elif 'delete_username' in request.form and delete_form.validate_on_submit():
            delete_username = request.form['delete_username']
            if delete_username and delete_username != current_user.username:
                user_to_delete = User.query.filter_by(username=delete_username).first()
                if user_to_delete:
                    db.session.delete(user_to_delete)
                    db.session.commit()
                    flash(f"User '{delete_username}' deleted successfully!", 'success')
                else:
                    flash(f"User '{delete_username}' not found!", 'danger')
            else:
                flash("Cannot delete yourself!", 'danger')

            return redirect(url_for('manage_users'))

    # Render template with forms and data
    user_data = {u.username: {'role': u.role, 'hub': u.hub} for u in users}
    return render_template(
        'manage_users.html',
        add_form=add_form,
        delete_form=delete_form,
        users=user_data,
        current_user=current_user
    )


@app.route('/delete_package/<tracking_id>', methods=['POST'])
@login_required
@role_required(['super_admin'])
def delete_package(tracking_id):
    # Load package data
    with open(PACKAGES_FILE, 'r') as file:
        packages = json.load(file)

    if tracking_id in packages:
        del packages[tracking_id]

        # Save the updated package data
        with open(PACKAGES_FILE, 'w') as file:
            json.dump(packages, file, indent=4)

        flash(f'Package {tracking_id} deleted successfully!', 'success')
    else:
        flash('Package not found!', 'danger')

    return redirect(url_for('admin_dashboard'))


# Ensure key pairs exist for all users
ensure_key_pairs()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo, Optional

class EditStatusForm(FlaskForm):
    status = SelectField(
        'Status',
        choices=[
            ('Registered', 'Registered'),
            ('In Transit', 'In Transit'),
            ('Out for Delivery', 'Out for Delivery'),
            ('Delivered', 'Delivered'),
            ('Delayed', 'Delayed'),
            ('Returned to Sender', 'Returned to Sender')
        ],
        validators=[DataRequired()]
    )

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=25)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')


class AdminLoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    two_factor_code = StringField('2FA Code (Optional)', validators=[Optional()])  # Optional field
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')


class TrackForm(FlaskForm):
    tracking_id = StringField('Tracking ID', validators=[DataRequired()])
    submit = SubmitField('Track')


class CreateShipmentForm(FlaskForm):
    sender_name = StringField('Sender Name', validators=[DataRequired()])
    receiver_name = StringField('Receiver Name', validators=[DataRequired()])
    origin = StringField('Origin Hub', validators=[DataRequired()])
    destination = StringField('Destination Hub', validators=[DataRequired()])
    submit = SubmitField('Create Shipment')


class AddPackageForm(FlaskForm):
    tracking_id = StringField('Tracking ID (optional)')  # Can be empty, auto-generated
    sender_name = StringField('Sender Name', validators=[DataRequired()])
    receiver_name = StringField('Receiver Name', validators=[DataRequired()])
    origin = StringField('Origin Hub', validators=[DataRequired()])
    destination = StringField('Destination Hub', validators=[DataRequired()])
    submit = SubmitField('Add Package')


class UpdateStatusForm(FlaskForm):
    location = StringField('Current Location', validators=[DataRequired()])
    status = SelectField('Status', choices=[
        ('Package Registered', 'Package Registered'),
        ('In Transit', 'In Transit'),
        ('Out for Delivery', 'Out for Delivery'),
        ('Delivered', 'Delivered'),
        ('Delayed', 'Delayed'),
        ('Returned', 'Returned'),
    ], validators=[DataRequired()])
    submit = SubmitField('Update Status')


class AddUserForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    role = SelectField('Role', choices=[('admin', 'Admin'), ('staff', 'Staff')], validators=[DataRequired()])
    hub = StringField('Hub', validators=[DataRequired()])
    submit = SubmitField('Add User')


class DeleteUserForm(FlaskForm):
    delete_username = StringField('Username to Delete', validators=[DataRequired()])
    submit = SubmitField('Delete User')

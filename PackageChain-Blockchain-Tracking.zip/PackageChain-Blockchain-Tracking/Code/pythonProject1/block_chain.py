import hashlib
import json
import random
import string
import time
from datetime import datetime


def generate_tracking_id(length=8):
    """Generate a random tracking ID with the format PKG-XXXXXXXX"""
    # Generate a random string of uppercase letters and numbers
    chars = string.ascii_uppercase + string.digits
    random_str = ''.join(random.choice(chars) for _ in range(length))
    return f"PKG-{random_str}"


def calculate_hash(block):
    """Calculate SHA-256 hash of a block"""
    # Create a copy of the block without the hash and signature fields
    block_copy = block.copy()
    block_copy.pop('hash', None)
    block_copy.pop('signature', None)

    # Convert to sorted JSON string and hash
    block_string = json.dumps(block_copy, sort_keys=True)
    return hashlib.sha256(block_string.encode()).hexdigest()


def create_genesis_block(sender_name, receiver_name, origin, destination, created_by):
    """Create the first block of a package chain"""
    block = {
        'index': 0,
        'timestamp': datetime.utcnow().isoformat(),
        'location': origin,
        'status': 'Package Registered',
        'sender_name': sender_name,
        'receiver_name': receiver_name,
        'origin': origin,
        'destination': destination,
        'updated_by': created_by,
        'prev_hash': '0' * 64,  # Genesis block has a special prev_hash
    }

    # Calculate and add the hash
    block['hash'] = calculate_hash(block)
    return block


def create_block(previous_block, location, status, updated_by):
    """Create a new block in the package chain"""
    block = {
        'index': previous_block['index'] + 1,
        'timestamp': datetime.utcnow().isoformat(),
        'location': location,
        'status': status,
        'updated_by': updated_by,
        'prev_hash': previous_block['hash'],

        # Copy some data from the genesis block for reference
        'sender_name': previous_block.get('sender_name'),
        'receiver_name': previous_block.get('receiver_name'),
        'origin': previous_block.get('origin'),
        'destination': previous_block.get('destination'),
    }

    # Calculate and add the hash
    block['hash'] = calculate_hash(block)
    return block


def verify_chain(chain):
    """Verify the integrity of the entire blockchain"""
    if not chain:
        return False

    # Check each block
    for i in range(1, len(chain)):
        current_block = chain[i]
        previous_block = chain[i - 1]

        # Check if hash is valid
        if current_block['hash'] != calculate_hash(current_block):
            return False

        # Check if previous hash link is valid
        if current_block['prev_hash'] != previous_block['hash']:
            return False

    return True


def verify_block(block, previous_block=None):
    """Verify a single block"""
    # Verify hash integrity
    if block['hash'] != calculate_hash(block):
        return False

    # If previous block is provided, check the link
    if previous_block:
        if block['prev_hash'] != previous_block['hash']:
            return False

        # Check index continuity
        if block['index'] != previous_block['index'] + 1:
            return False

    return True
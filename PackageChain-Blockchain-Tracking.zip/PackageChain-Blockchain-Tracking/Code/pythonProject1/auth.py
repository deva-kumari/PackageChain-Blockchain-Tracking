import pyotp
import base64
import os
import logging
from models import User, db

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def authenticate(username, password, two_factor_code=None):
    """
    Authenticate a user based on username and password.
    Optionally validate 2FA code if implemented.

    Returns a dict with success status and error message if applicable.
    """
    try:
        user = User.query.filter_by(username=username).first()

        # Check if user exists and password is correct
        if not user or not user.check_password(password):
            return {
                'success': False,
                'error': 'Invalid username or password',
                'user': None
            }

        # Check 2FA for admin/staff users
        if user.is_admin():
            # Only enforce 2FA for admin users if a secret key is set
            # This allows initial admin login and 2FA setup later
            if two_factor_code:
                # Get or generate TOTP secret
                totp_secret = get_or_create_totp_secret(user)

                # Verify 2FA code
                totp = pyotp.TOTP(totp_secret)
                if not totp.verify(two_factor_code):
                    return {
                        'success': False,
                        'error': 'Invalid two-factor code',
                        'user': None
                    }

        # Authentication successful
        return {
            'success': True,
            'error': None,
            'user': user
        }
    except Exception as e:
        logger.error(f"Authentication error: {str(e)}")
        return {
            'success': False,
            'error': 'An error occurred during authentication',
            'user': None
        }


def get_or_create_totp_secret(user):
    """
    Get or create a TOTP secret for the user.
    Normally you would store this in the database, but we'll use a simple file for demonstration.
    """
    secret_path = os.path.join('data', f"{user.username}_totp_secret.txt")

    if os.path.exists(secret_path):
        # Load existing secret
        with open(secret_path, 'r') as f:
            return f.read().strip()
    else:
        # Generate new secret
        secret = pyotp.random_base32()
        os.makedirs('data', exist_ok=True)
        with open(secret_path, 'w') as f:
            f.write(secret)
        return secret


def is_authorized(username, role_required=None, hub_required=None):
    """
    Check if a user is authorized for a specific role or hub.

    Returns a dict with authorized status and error message if applicable.
    """
    try:
        user = User.query.filter_by(username=username).first()

        if not user:
            return {'authorized': False, 'error': 'User not found'}

        # Check role if required
        if role_required and user.role not in role_required:
            return {
                'authorized': False,
                'error': f'You need one of these roles: {", ".join(role_required)}'
            }

        # Check hub if required (staff users are limited to specific hubs)
        if hub_required and user.role == 'staff':
            if user.hub != hub_required and user.hub != 'all':
                return {
                    'authorized': False,
                    'error': f'You do not have access to {hub_required} hub'
                }

        return {'authorized': True, 'error': None}
    except Exception as e:
        logger.error(f"Authorization error: {str(e)}")
        return {'authorized': False, 'error': 'An error occurred during authorization check'}


def generate_totp_qr_code(username):
    """
    Generate a QR code URL for 2FA setup.
    This would be displayed to the user during 2FA setup.
    """
    try:
        user = User.query.filter_by(username=username).first()

        if not user:
            return None

        # Get or create TOTP secret
        totp_secret = get_or_create_totp_secret(user)

        # Create a TOTP object
        totp = pyotp.TOTP(totp_secret)

        # Generate a provisioning URI for QR code
        provisioning_uri = totp.provisioning_uri(
            name=username,
            issuer_name="PackageChain"
        )

        return provisioning_uri
    except Exception as e:
        logger.error(f"Error generating TOTP QR code: {str(e)}")
        return None